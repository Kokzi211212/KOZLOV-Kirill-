# OOP Java Console App – SOLID Principles

This is a console-based Java application demonstrating the use of **SOLID principles**.  
The app supports basic user and article management features and can be optionally deployed via Docker.

## 🧱 Technologies Used
- Java 17+
- Maven
- Docker (optional)
- JUnit (for testing)

## 🧪 How to Build & Run

### Prerequisites
- Java 11/17+
- Maven
- (Optional) Docker & Docker Compose

### Local Run

```bash
mvn clean install
mvn exec:java -Dexec.mainClass="org.oop.Main"
```

### Docker Run

```bash
docker-compose up --build
```

## ✅ Features
- Article creation, listing, commenting
- Basic authentication
- Console-based interaction
- Extensible command architecture
- Compliant with SOLID principles

## 📦 Structure
- `model/` – entities
- `service/` – logic
- `commands/` – user commands
- `api/` – interfaces
- `dao/` – data access

---

## 🔧 For Developers

```bash
# Run tests
mvn test

# Generate JAR
mvn package
```

## 🤝 Contribution

Fork this repo, make changes, and open a pull request!

---

**Author**: Your Name  
**License**: MIT
