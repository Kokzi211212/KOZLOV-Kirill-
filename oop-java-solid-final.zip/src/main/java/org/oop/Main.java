package org.oop;

public class Main {
    public static void main(String[] args) {
        App.getInstance().run();
    }
}