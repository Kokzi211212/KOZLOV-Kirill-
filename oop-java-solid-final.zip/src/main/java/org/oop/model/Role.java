package org.oop.model;

public enum Role {
    ADMIN,
    USER
}
