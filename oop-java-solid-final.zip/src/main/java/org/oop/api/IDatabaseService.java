package org.oop.api;

public interface IDatabaseService {

    void initializeDatabase();
}
