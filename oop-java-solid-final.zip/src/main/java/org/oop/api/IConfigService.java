package org.oop.api;

public interface IConfigService {
    String getProperty(String propertyName);
}
